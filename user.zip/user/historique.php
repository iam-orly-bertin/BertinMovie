<?php
require_once __DIR__ . '/../includes/session_boot.php';
require_once __DIR__ . '/../connexion.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/update_session.php';
require_once __DIR__ . '/../includes/notification.php';

if (isset($_SESSION['user_id'])) {
    updateUserSession($pdo, $_SESSION['user_id']);
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// =========================================================
// EFFACER L'HISTORIQUE
// =========================================================
if (isset($_GET['clear']) && $_GET['clear'] === 'all') {
    try {
        $pdo->prepare("DELETE FROM historique_vue WHERE id_utilisateur = ?")->execute([$user_id]);
        showNotif('success', "✅ Historique effacé avec succès !");
    } catch (PDOException $e) {
        showNotif('error', "❌ Erreur lors de l'effacement de l'historique");
    }
    header("Location: historique.php");
    exit();
}

// Créer la table si elle n'existe pas
try {
    $pdo->query("SELECT 1 FROM historique_vue LIMIT 1");
} catch (PDOException $e) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS historique_vue (
        id_historique INT AUTO_INCREMENT PRIMARY KEY,
        id_utilisateur INT NOT NULL,
        id_video INT NOT NULL,
        date_vue TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
}

$historique = $pdo->prepare("
    SELECT f.*, v.id_video, v.thumbnail, v.views, c.nom_categorie, h.date_vue
    FROM historique_vue h
    INNER JOIN video_film v ON h.id_video = v.id_video
    INNER JOIN film f ON v.id_film = f.id_film
    LEFT JOIN categorie c ON f.id_categorie = c.id_categorie
    WHERE h.id_utilisateur = ? AND f.is_deleted = 0 AND f.est_archive = 0
    ORDER BY h.date_vue DESC
");
$historique->execute([$user_id]);
$videos = $historique->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-lang-fr="Mon historique" data-lang-en="My history">Mon historique</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/film_web_dy/user/css/style-user.css">
    <style>
        /* =========================================================
           HISTORIQUE.PHP - STYLES
           ========================================================= */

        .historique-container {
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            padding: 10px 16px 100px;
        }

        /* =========================================================
           PAGE HEADER
           ========================================================= */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 24px;
        }

        .page-header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary, #0f172a);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }

        .page-header h1 i {
            color: #3b82f6;
            font-size: 26px;
        }

        .page-header h1 span {
            color: var(--text-secondary, #64748b);
            font-weight: 400;
            font-size: 18px;
        }

        body.dark-mode .page-header h1 {
            color: #e2e8f0;
        }

        body.dark-mode .page-header h1 span {
            color: #94a3b8;
        }

        /* =========================================================
           BOUTON EFFACER L'HISTORIQUE
           ========================================================= */
        .btn-clear-history {
            padding: 10px 20px;
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: #ffffff;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 2px 12px rgba(239, 68, 68, 0.25);
            text-decoration: none;
        }

        .btn-clear-history:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 24px rgba(239, 68, 68, 0.35);
            background: linear-gradient(135deg, #dc2626, #b91c1c);
        }

        .btn-clear-history:active {
            transform: scale(0.97);
        }

        body.dark-mode .btn-clear-history {
            box-shadow: 0 2px 12px rgba(239, 68, 68, 0.15);
        }

        /* =========================================================
           GRILLE
           ========================================================= */
        .movies-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }

        /* =========================================================
           CARTE FILM
           ========================================================= */
        .movie-card {
            background: var(--bg-card, #ffffff);
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid var(--border-color, #e2e8f0);
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
        }

        .movie-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 30px rgba(59, 130, 246, 0.12);
            border-color: #3b82f6;
        }

        body.dark-mode .movie-card {
            background: #1e293b;
            border-color: #334155;
        }

        body.dark-mode .movie-card:hover {
            border-color: #3b82f6;
            box-shadow: 0 8px 30px rgba(59, 130, 246, 0.15);
        }

        /* =========================================================
           MINIATURE
           ========================================================= */
        .thumb {
            position: relative;
            padding-top: 56.25%;
            background: #f1f5f9;
            overflow: hidden;
        }

        body.dark-mode .thumb {
            background: #0f172a;
        }

        .thumb img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .movie-card:hover .thumb img {
            transform: scale(1.05);
        }

        .no-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: #e5edff;
            color: #3b82f6;
            font-weight: 500;
            font-size: 14px;
            padding: 10px;
            text-align: center;
        }

        body.dark-mode .no-image {
            background: #1e293b;
            color: #60a5fa;
        }

        .no-image i {
            font-size: 36px;
            margin-bottom: 8px;
            opacity: 0.5;
        }

        /* =========================================================
           DURÉE
           ========================================================= */
        .duration {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: rgba(0, 0, 0, 0.8);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 6px;
            backdrop-filter: blur(4px);
        }

        /* =========================================================
           BADGE "VU"
           ========================================================= */
        .badge-top {
            position: absolute;
            top: 12px;
            left: 12px;
            background: #3b82f6;
            color: #ffffff;
            font-size: 11px;
            font-weight: 600;
            padding: 4px 14px;
            border-radius: 20px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
            display: flex;
            align-items: center;
            gap: 4px;
            backdrop-filter: blur(4px);
        }

        .badge-top i {
            font-size: 10px;
        }

        /* =========================================================
           INFOS
           ========================================================= */
        .info {
            padding: 16px 16px 18px;
        }

        .info h4 {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-primary, #0f172a);
            margin: 0 0 8px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        body.dark-mode .info h4 {
            color: #e2e8f0;
        }

        .info .meta {
            display: flex;
            gap: 12px;
            font-size: 12px;
            color: var(--text-secondary, #64748b);
            margin-bottom: 12px;
            flex-wrap: wrap;
        }

        body.dark-mode .info .meta {
            color: #94a3b8;
        }

        .info .meta span {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .info .meta i {
            color: #3b82f6;
            font-size: 12px;
        }

        /* =========================================================
           BOUTON REPRENDRE
           ========================================================= */
        .btn-play {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 10px 16px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: #ffffff;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-play:hover {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(59, 130, 246, 0.35);
        }

        .btn-play:active {
            transform: scale(0.97);
        }

        /* =========================================================
           ÉTAT VIDE
           ========================================================= */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: var(--bg-card, #ffffff);
            border-radius: 20px;
            border: 1px solid var(--border-color, #e2e8f0);
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
        }

        body.dark-mode .empty-state {
            background: #1e293b;
            border-color: #334155;
        }

        .empty-state i {
            font-size: 56px;
            color: #94a3b8;
            margin-bottom: 16px;
            display: block;
        }

        body.dark-mode .empty-state i {
            color: #475569;
        }

        .empty-state h3 {
            font-size: 22px;
            font-weight: 700;
            color: var(--text-primary, #0f172a);
            margin-bottom: 8px;
        }

        body.dark-mode .empty-state h3 {
            color: #e2e8f0;
        }

        .empty-state p {
            color: var(--text-secondary, #64748b);
            max-width: 400px;
            margin: 0 auto 20px;
            font-size: 15px;
        }

        body.dark-mode .empty-state p {
            color: #94a3b8;
        }

        .empty-state .btn-play {
            display: inline-flex;
            width: auto;
            padding: 12px 32px;
        }

        /* =========================================================
           ANIMATION
           ========================================================= */
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .movie-card {
            animation: slideUp 0.4s ease-out both;
        }

        .movie-card:nth-child(1) {
            animation-delay: 0.00s;
        }

        .movie-card:nth-child(2) {
            animation-delay: 0.05s;
        }

        .movie-card:nth-child(3) {
            animation-delay: 0.10s;
        }

        .movie-card:nth-child(4) {
            animation-delay: 0.15s;
        }

        .movie-card:nth-child(5) {
            animation-delay: 0.20s;
        }

        .movie-card:nth-child(6) {
            animation-delay: 0.25s;
        }

        .movie-card:nth-child(7) {
            animation-delay: 0.30s;
        }

        .movie-card:nth-child(8) {
            animation-delay: 0.35s;
        }

        .movie-card:nth-child(9) {
            animation-delay: 0.40s;
        }

        .movie-card:nth-child(10) {
            animation-delay: 0.45s;
        }

        /* =========================================================
           RESPONSIVE - MOBILE
           ========================================================= */
        @media (max-width: 768px) {
            .historique-container {
                padding: 8px 12px 90px;
            }

            .page-header h1 {
                font-size: 20px;
            }

            .page-header h1 i {
                font-size: 22px;
            }

            .movies-grid {
                grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
                gap: 16px;
            }

            .info {
                padding: 12px 14px 14px;
            }

            .info h4 {
                font-size: 14px;
            }

            .btn-play {
                font-size: 13px;
                padding: 8px 12px;
            }

            .badge-top {
                font-size: 10px;
                padding: 3px 12px;
                top: 10px;
                left: 10px;
            }

            .btn-clear-history {
                font-size: 13px;
                padding: 8px 16px;
            }
        }

        @media (max-width: 480px) {
            .historique-container {
                padding: 6px 8px 80px;
            }

            .page-header {
                flex-direction: column;
                align-items: stretch;
                gap: 12px;
            }

            .page-header h1 {
                font-size: 17px;
            }

            .page-header h1 i {
                font-size: 18px;
            }

            .page-header h1 span {
                font-size: 14px;
            }

            .btn-clear-history {
                width: 100%;
                justify-content: center;
                font-size: 13px;
                padding: 10px;
            }

            .movies-grid {
                grid-template-columns: 1fr 1fr;
                gap: 12px;
            }

            .info {
                padding: 10px 10px 12px;
            }

            .info h4 {
                font-size: 12px;
                margin-bottom: 4px;
            }

            .info .meta {
                font-size: 10px;
                gap: 8px;
                margin-bottom: 8px;
                flex-direction: column;
                gap: 2px;
            }

            .info .meta i {
                font-size: 10px;
            }

            .btn-play {
                font-size: 11px;
                padding: 6px 10px;
                border-radius: 8px;
            }

            .btn-play i {
                font-size: 10px;
            }

            .badge-top {
                font-size: 9px;
                padding: 2px 10px;
                top: 8px;
                left: 8px;
            }

            .badge-top i {
                font-size: 8px;
            }

            .duration {
                font-size: 10px;
                padding: 2px 8px;
                bottom: 8px;
                right: 8px;
            }

            .empty-state {
                padding: 40px 16px;
            }

            .empty-state i {
                font-size: 40px;
            }

            .empty-state h3 {
                font-size: 18px;
            }

            .empty-state p {
                font-size: 13px;
            }

            .empty-state .btn-play {
                font-size: 13px;
                padding: 10px 24px;
            }
        }

        @media (max-width: 380px) {
            .historique-container {
                padding: 4px 4px 70px;
            }

            .page-header h1 {
                font-size: 15px;
            }

            .movies-grid {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }

            .info {
                padding: 6px 8px 10px;
            }

            .info h4 {
                font-size: 11px;
            }

            .info .meta {
                font-size: 9px;
            }

            .btn-play {
                font-size: 10px;
                padding: 4px 8px;
                border-radius: 6px;
            }

            .badge-top {
                font-size: 8px;
                padding: 2px 8px;
                top: 6px;
                left: 6px;
            }

            .duration {
                font-size: 9px;
                padding: 2px 6px;
                bottom: 6px;
                right: 6px;
            }
        }
    </style>
</head>

<body>

    <?php include __DIR__ . '/includes/menu-user.php'; ?>
    <?php renderNotifications(); ?>

    <div class="historique-container">
        <!-- ===== PAGE HEADER ===== -->
        <div class="page-header">
            <h1>
                <i class="fas fa-history"></i>
                <span data-lang-fr="Mon historique" data-lang-en="My history">Mon historique</span>
                <span>(
                    <?= count($videos) ?>)
                </span>
            </h1>
            <?php if (count($videos) > 0): ?>
                <a href="historique.php?clear=all" class="btn-clear-history" onclick="return confirmClearHistory(event)">
                    <i class="fas fa-trash-alt"></i>
                    <span data-lang-fr="Effacer l'historique" data-lang-en="Clear history">Effacer l'historique</span>
                </a>
            <?php endif; ?>
        </div>

        <!-- ===== GRILLE ===== -->
        <?php if (count($videos) > 0): ?>
            <div class="movies-grid">
                <?php foreach ($videos as $film): ?>
                    <div class="movie-card">
                        <div class="thumb">
                            <?php if (!empty($film['thumbnail'])): ?>
                                <img src="<?= htmlspecialchars($film['thumbnail']) ?>"
                                    alt="<?= htmlspecialchars($film['nom_film']) ?>" loading="lazy">
                            <?php else: ?>
                                <div class="no-image">
                                    <i class="fas fa-film"></i>
                                    <span>
                                        <?= htmlspecialchars($film['nom_film']) ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            <span class="duration">
                                <?= htmlspecialchars($film['duree'] ?? '00:00') ?>
                            </span>
                            <span class="badge-top">
                                <i class="fas fa-check-circle"></i>
                                <span data-lang-fr="Vu" data-lang-en="Watched">Vu</span>
                            </span>
                        </div>
                        <div class="info">
                            <h4>
                                <?= htmlspecialchars($film['nom_film']) ?>
                            </h4>
                            <div class="meta">
                                <span><i class="fas fa-eye"></i>
                                    <?= number_format($film['views'] ?? 0, 0, ',', ' ') ?>
                                </span>
                                <span><i class="fas fa-clock"></i>
                                    <?= date('d/m/Y', strtotime($film['date_vue'])) ?>
                                </span>
                                <span><i class="fas fa-tag"></i>
                                    <?= htmlspecialchars($film['nom_categorie'] ?? 'Non catégorisé') ?>
                                </span>
                            </div>
                            <a href="/film_web_dy/user/watch.php?id_video=<?= $film['id_video'] ?>" class="btn-play">
                                <i class="fas fa-play"></i>
                                <span data-lang-fr="Reprendre" data-lang-en="Resume">Reprendre</span>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-history"></i>
                <h3 data-lang-fr="Aucun historique" data-lang-en="No history">Aucun historique</h3>
                <p data-lang-fr="Commencez à regarder des films pour remplir votre historique."
                    data-lang-en="Start watching movies to fill your history.">
                    Commencez à regarder des films pour remplir votre historique.
                </p>
                <a href="video.php" class="btn-play">
                    <i class="fas fa-film"></i>
                    <span data-lang-fr="Découvrir des vidéos" data-lang-en="Discover videos">Découvrir des vidéos</span>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // =========================================================
        // CONFIRMATION EFFACER L'HISTORIQUE
        // =========================================================
        function confirmClearHistory(e) {
            e.preventDefault();
            var lang = localStorage.getItem('lang') || 'fr';
            var messages = {
                fr: {
                    confirm: 'Voulez-vous vraiment effacer tout votre historique de visionnage ?',
                    yes: 'Oui, tout effacer',
                    no: 'Annuler'
                },
                en: {
                    confirm: 'Do you really want to clear all your watch history?',
                    yes: 'Yes, clear all',
                    no: 'Cancel'
                }
            };

            var msg = messages[lang] || messages.fr;

            if (confirm(msg.confirm)) {
                window.location.href = 'historique.php?clear=all';
            }
            return false;
        }

        // =========================================================
        // TRADUCTION DES TEXTES
        // =========================================================
        document.addEventListener('DOMContentLoaded', function () {
            var lang = localStorage.getItem('lang') || 'fr';

            // Les traductions sont gérées par menu-user.php
            // Cette fonction est juste un fallback
            document.querySelectorAll('[data-lang-fr][data-lang-en]').forEach(function (el) {
                var text = el.getAttribute('data-lang-' + lang);
                if (text !== null) {
                    // Ne pas remplacer si c'est un lien avec icône
                    if (el.children.length > 0) {
                        var span = el.querySelector('span');
                        if (span) {
                            span.textContent = text;
                        }
                    } else {
                        el.textContent = text;
                    }
                }
            });
        });
    </script>

</body>

</html>